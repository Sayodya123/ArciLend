# ArciLend: Private Credit Scoring on Solana

## Project Title
**ArciLend — Private Credit Scoring on Solana**

## Mission Fulfillment
ArciLend demonstrates how confidential computing (via Arcium) can be combined with Solana smart contracts to implement private credit scoring for lending. Sensitive inputs (a user's Risk Factor) are encrypted client-side and processed within Arcium's secure environment. The on-chain Anchor program only stores public metadata (loan amount, borrower) and the final non-sensitive result (interest rate). This prevents exposure of private financial indicators while still enabling decentralized lending.

## Components
- `programs/arcium_lend` — Anchor Rust program (on-chain orchestrator).
- `arcium_anchor` — a small local stub crate simulating Arcium's on-chain helper (replace with real `arcium-anchor` crate).
- `app/src/App.tsx` — simplified frontend stub.
- `tests/arcium_lend.ts` — TypeScript test demonstrating the flow (init -> queue -> finalize).
- `Anchor.toml`, `Cargo.toml`, and packaging/scripts.

## Privacy Explanation (CRITICAL)
### How Arcium is Used
- The **Risk Factor** (sensitive user data) is encrypted in the client using Arcium MXE public key.
- The encrypted blob is submitted to the Solana program as an opaque byte array.
- Arcium MPC performs the computation off-chain in a confidential environment and only returns the **final interest rate** on-chain through a verified callback.
- The Solana program never sees plaintext Risk Factor; it only sees the encrypted input and the final (non-sensitive) interest rate.

### Privacy Benefits
- **No exposure of raw private data**: Risk Factor remains encrypted and is only decrypted inside Arcium.
- **Reduced MEV / front-running risk**: Because private inputs are not on-chain, adversaries cannot front-run computations that depend on sensitive user data.
- **Auditability**: The on-chain loan record contains only public fields and a non-sensitive interest rate. Computation proofs (if provided by Arcium) can also be stored or referenced.

## Files Explained
- `programs/arcium_lend/src/lib.rs` — Anchor program with three main instructions:
  1. `init_comp_def` — register the Arcium computation definition (one-time).
  2. `request_loan_and_queue_comp` — create LoanAccount and queue confidential computation by submitting encrypted input.
  3. `finalize_loan_rate` — callback used by Arcium to store the computed interest rate.
- `arcium_anchor` — local stub that illustrates the expected API surface of the `arcium-anchor` crate.
- `tests/arcium_lend.ts` — a mocha test that demonstrates the end-to-end logical flow. It uses a fake encryption helper for demonstration.

## Setup / Build / Test Instructions
> These steps assume you have Rust, Solana CLI, Anchor, Node.js and yarn/npm installed.

1. Clone or extract the project folder:
   ```bash
   unzip arcium_lend_project.zip -d arcium_lend_project
   cd arcium_lend_project
   ```

2. Install JS deps (for tests):
   ```bash
   npm install
   ```

3. Build & deploy the Anchor program (local/devnet):
   - Configure Anchor provider (e.g., devnet or localnet):
     ```bash
     export ANCHOR_PROVIDER_URL="https://api.devnet.solana.com"
     export ANCHOR_WALLET="~/.config/solana/id.json"
     ```
   - Build:
     ```bash
     anchor build
     ```
   - Deploy (if desired):
     ```bash
     anchor deploy --provider.cluster devnet
     ```

4. Run tests:
   ```bash
   npm test
   ```
   The test demonstrates:
   - Initializing the computation definition.
   - Requesting a loan with an encrypted risk factor.
   - Simulating Arcium's off-chain computation and calling the finalize callback.
   - Asserting that the on-chain LoanAccount has the expected interest rate.

## Notes & Next Steps
- Replace the `arcium_anchor` stub with the real `arcium-anchor` crate from Arcium and configure proper CPI calls and authentication checks for callbacks.
- Integrate the real Arcium MXE JS client in the frontend to perform proper client-side encryption with the Arcium public key.
- Add robust access control and verification for callback authenticity (e.g., signatures, program-derived authorities).
- Add event logging and optional computation proof storage for verifiable audits.

## Hackathon Submission Checklist
- Project name: ArciLend
- Goal: Demonstrate Private Credit Scoring on Solana using Arcium MPC
- Included files: Anchor program, local arcium stub crate, example frontend stub, test script, README.
- How privacy is preserved: Sensitive Risk Factor encrypted client-side, decrypted only inside Arcium, only final interest rate on-chain.

Good luck with the Arcium track of the Cypherpunk hackathon!

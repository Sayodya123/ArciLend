// Example test script demonstrating the ArciLend flow.
// NOTE: This script is illustrative and assumes you have the Anchor CLI and local validator set up.
// It uses a stubbed 'arcium-js' style encryption for creating an 'encrypted' payload.
// The test performs: init_comp_def -> request_loan_and_queue_comp -> simulate Arcium callback finalize_loan_rate

import * as anchor from "@project-serum/anchor";
import { Program } from "@project-serum/anchor";
import { Keypair, PublicKey, SystemProgram } from "@solana/web3.js";
import assert from "assert";
import fs from "fs";
import path from "path";

describe("arcium_lend", () => {
  // Configure the client to use the local cluster.
  const provider = anchor.AnchorProvider.env();
  anchor.setProvider(provider);

  const program = anchor.workspace.ArciumLend as Program;

  // Helper: fake 'encryption' - in production you must use Arcium MXE JS library to encrypt data with Arcium public key.
  function fakeArciumEncrypt(riskFactor: number): Uint8Array {
    // This stub encodes the risk factor as a single byte prefixed with a marker.
    // Real encryption will produce a larger opaque blob.
    return Uint8Array.from([0x41, riskFactor & 0xff]);
  }

  it("Init -> Queue -> Finalize", async () => {
    // Accounts / keys
    const authority = provider.wallet;
    const compDefKeypair = anchor.web3.Keypair.generate();

    // Initialize computation definition
    const arciumProgramId = new PublicKey("ArciM1111111111111111111111111111111111111"); // stub arcium program
    await program.rpc.initCompDef(arciumProgramId, {
      accounts: {
        compDef: compDefKeypair.publicKey,
        arciumProgram: arciumProgramId,
        authority: authority.publicKey,
        systemProgram: SystemProgram.programId,
      },
      signers: [compDefKeypair],
      instructions: [
        await program.account.compDef.createInstruction(compDefKeypair),
      ],
    });

    // Request a loan and queue computation
    const loanId = new anchor.BN(1);
    const amount = new anchor.BN(1_000_000); // lamports or arbitrary units
    const borrower = provider.wallet.payer as Keypair;

    // Derive PDA for loan account (the program uses seeds: ["loan", borrower, loan_id])
    const [loanPda, bump] = await PublicKey.findProgramAddress(
      [Buffer.from("loan"), borrower.publicKey.toBuffer(), loanId.toArrayLike(Buffer, "le", 8)],
      program.programId
    );

    const riskFactor = 5; // a private, sensitive value
    const encrypted = fakeArciumEncrypt(riskFactor);

    await program.rpc.requestLoanAndQueueComp(loanId, amount, Array.from(encrypted), {
      accounts: {
        loanAccount: loanPda,
        borrower: borrower.publicKey,
        arciumProgram: arciumProgramId,
        systemProgram: SystemProgram.programId,
      },
      signers: [],
    });

    // Simulate Arcium completing the computation off-chain and making the on-chain callback.
    // For this demo we'll compute a toy interest rate: interest_rate = base 500 + riskFactor * 100
    const computedInterestRate = 500 + riskFactor * 100;

    // Call finalize_loan_rate as if from Arcium. In production Arcium would authorize and sign or
    // use a relayer; here we simply call the RPC.
    await program.rpc.finalizeLoanRate(new anchor.BN(computedInterestRate), [], {
      accounts: {
        compDef: compDefKeypair.publicKey,
        loanAccount: loanPda,
        arciumProgram: arciumProgramId,
      },
      signers: [],
    });

    // Fetch loan account and assert interest_rate set
    const loanAccount = await program.account.loanAccount.fetch(loanPda);
    console.log("Loan account:", loanAccount);
    assert.ok(Number(loanAccount.interestRate) === computedInterestRate, "Interest rate mismatch");
  });
});

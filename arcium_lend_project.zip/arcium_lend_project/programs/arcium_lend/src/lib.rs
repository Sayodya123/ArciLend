use anchor_lang::prelude::*;
use arcium_anchor::{self, QueueComputationArgs, ARCIUM_PROGRAM_PUBKEY};

declare_id!("ArciL1111111111111111111111111111111111111");

#[program]
pub mod arcium_lend {
    use super::*;

    pub fn init_comp_def(ctx: Context<InitCompDef>, comp_def_id: Pubkey) -> Result<()> {
        let comp = &mut ctx.accounts.comp_def;
        comp.authority = *ctx.accounts.authority.key;
        comp.comp_def_id = comp_def_id;
        // store arcium program id for verification during callback
        comp.arcium_program = ARCIUM_PROGRAM_PUBKEY;
        msg!("CompDef initialized: {:?}", comp.comp_def_id);
        Ok(())
    }

    pub fn request_loan_and_queue_comp(
        ctx: Context<RequestLoanAndQueueComp>,
        loan_id: u64,
        amount: u64,
        encrypted_risk_factor: Vec<u8>, // opaque encrypted bytes produced by Arcium MXE client
    ) -> Result<()> {
        let loan = &mut ctx.accounts.loan_account;
        let borrower = ctx.accounts.borrower.key();

        // Initialize loan account
        loan.loan_id = loan_id;
        loan.borrower = borrower;
        loan.amount = amount;
        loan.interest_rate = 0; // to be filled by Arcium callback
        msg!("Loan account created: id={}, borrower={}", loan_id, borrower);

        // Queue computation in Arcium (stubbed via local arcium_anchor crate)
        // We pass the encrypted input bytes as opaque data.
        let queue_args = QueueComputationArgs {
            encrypted_input: encrypted_risk_factor,
        };
        // In real implementation a CPI or event would be made to Arcium.
        // Here we call the helper function (no-op stub) to illustrate the flow.
        arcium_anchor::queue_computation(&ctx.accounts.arcium_program, queue_args)?;

        // Save a small on-chain log of the queued computation so auditors can trace the request.
        msg!("Computation queued for loan_id={}", loan_id);

        Ok(())
    }

    /// Finalize: called by Arcium cluster (off-chain -> on-chain callback).
    /// In practice Arcium will authorize this call. We require the caller to provide
    /// the comp_def account and the arcium program account to verify the source.
    pub fn finalize_loan_rate(
        ctx: Context<FinalizeLoanRate>,
        computed_interest_rate: u64,
        _proof: Vec<u8>, // placeholder for computation proof metadata (opaque)
    ) -> Result<()> {
        // Basic check: the caller must be the Arcium program (verified by comp_def)
        let comp_def = &ctx.accounts.comp_def;
        require_keys_eq!(comp_def.arcium_program, *ctx.accounts.arcium_program.key, ArciumAuthError);

        let loan = &mut ctx.accounts.loan_account;
        loan.interest_rate = computed_interest_rate;
        msg!(
            "Loan finalized: loan_id={} interest_rate={}",
            loan.loan_id,
            loan.interest_rate
        );
        Ok(())
    }
}

#[derive(Accounts)]
pub struct InitCompDef<'info> {
    #[account(init, payer = authority, space = 8 + 32 + 32 + 32)]
    pub comp_def: Account<'info, CompDef>,
    /// CHECK: Arcium program id (we store for verification)
    pub arcium_program: UncheckedAccount<'info>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct RequestLoanAndQueueComp<'info> {
    #[account(init_if_needed, payer = borrower, space = 8 + 8 + 32 + 8 + 8, seeds = [b"loan", borrower.key().as_ref(), &loan_id.to_le_bytes()], bump)]
    pub loan_account: Account<'info, LoanAccount>,
    #[account(mut)]
    pub borrower: Signer<'info>,
    /// CHECK: arcium program account (to pass into CPI stub)
    pub arcium_program: Program<'info, arcium_anchor::arcium_anchor::ArciumProgram>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct FinalizeLoanRate<'info> {
    #[account(mut, has_one = arcium_program)]
    pub comp_def: Account<'info, CompDef>,
    #[account(mut, seeds = [b"loan", loan_account.borrower.as_ref(), &loan_account.loan_id.to_le_bytes()], bump)]
    pub loan_account: Account<'info, LoanAccount>,
    /// CHECK: Arcium program account provided by external relayer for verification.
    pub arcium_program: UncheckedAccount<'info>,
}

#[account]
pub struct CompDef {
    pub authority: Pubkey,
    pub comp_def_id: Pubkey,
    pub arcium_program: Pubkey,
}

#[account]
pub struct LoanAccount {
    pub loan_id: u64,
    pub borrower: Pubkey,
    pub amount: u64,
    pub interest_rate: u64,
}

#[error_code]
pub enum ArciumAuthError {
    #[msg("Invalid Arcium program authority")]
    InvalidArciumAuthority,
}

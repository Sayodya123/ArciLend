// Minimal local stub of the arcium-anchor crate to simulate Arcium integration.
// This crate provides a tiny on-chain API (no-op) that the Anchor program can call
// to "queue" a confidential computation and validate a callback.
//
// In a real integration you would replace this with the real `arcium-anchor` crate.
use anchor_lang::prelude::*;

declare_id!("ArciM1111111111111111111111111111111111111");

pub const ARCIUM_PROGRAM_PUBKEY: Pubkey = crate::ID;

#[derive(AnchorSerialize, AnchorDeserialize, Clone, Default)]
pub struct QueueComputationArgs {
    // Serialized encrypted input bytes (opaque to Solana program).
    pub encrypted_input: Vec<u8>,
    // A callback discriminator or metadata could be added here.
}

pub fn queue_computation<'a, 'b, 'c, 'info>(
    _program: &Program<'info, ArciumProgram>,
    _args: QueueComputationArgs,
) -> Result<()> {
    // This is a stub. The real arcium-anchor crate would perform
    // CPI to Arcium's on-chain program (or register an off-chain job).
    msg!("arcium-anchor: queue_computation called (stub).");
    Ok(())
}

#[program]
pub mod arcium_anchor {
    use super::*;
    pub fn dummy(_ctx: Context<Dummy>) -> Result<()> {
        Ok(())
    }
}

#[derive(Accounts)]
pub struct Dummy {}

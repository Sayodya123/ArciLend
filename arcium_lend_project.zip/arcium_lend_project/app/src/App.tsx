import React from "react";

export default function App() {
  return (
    <div style={{ padding: 24, fontFamily: "Arial, sans-serif" }}>
      <h1>ArciLend — Private Credit Scoring Demo</h1>
      <p>
        This is a simplified frontend stub. The proper flow would:
      </p>
      <ol>
        <li>Take user Risk Factor (private) and encrypt it using Arcium MXE public key.</li>
        <li>Send a transaction to request_loan_and_queue_comp with encrypted payload.</li>
        <li>Wait for Arcium to compute the interest rate and callback finalize_loan_rate.</li>
      </ol>
      <p>See the tests folder for an automated demo flow.</p>
    </div>
  );
}
